import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;


import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exceptions.InValidProductCodeException;
import com.capgemini.salesmanagement.util.CollectionUtil;

//import bin.com.cg.payroll.exceptions.AssociateDetailNotFoundException;


class Junit {

	@BeforeClass
	public static void setUpTestEnv() {
	//service=new  ISaleService();
		
	}
	@Before
	public void setUpTestData()
	{
		Sale sale1= new Sale(2, "tv", "Electronic",LocalDate.MAX , 3, 7);
		Sale sale2= new Sale(2, "tv", "Electronic", LocalDate.MIN, 3, 6);
	
	}
	
	@Test
	public void testSalesDataForInvalidSalesId()throws InValidProductCodeException{
		CollectionUtil.getSalesId();
		
	}	
	
	
	@After
		public void tearDownTestData() {
			CollectionUtil.sales.clear();
		Sale salesId = null;
		Sale sale = CollectionUtil.sales.get(salesId);
			
	
		}
	@Test
	void test() {
	
	}

}
