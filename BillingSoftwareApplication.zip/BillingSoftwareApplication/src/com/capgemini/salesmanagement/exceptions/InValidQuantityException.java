package com.capgemini.salesmanagement.exceptions;

public class InValidQuantityException  extends RuntimeException{

	public InValidQuantityException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InValidQuantityException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InValidQuantityException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InValidQuantityException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InValidQuantityException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
