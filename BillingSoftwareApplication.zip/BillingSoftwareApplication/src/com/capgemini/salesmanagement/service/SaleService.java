package com.capgemini.salesmanagement.service;

import java.time.LocalDate;
import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exceptions.InValidProductCategoryException;
import com.capgemini.salesmanagement.exceptions.InValidProductCodeException;
import com.capgemini.salesmanagement.exceptions.InValidProductNameException;
import com.capgemini.salesmanagement.exceptions.InValidQuantityException;
import com.capgemini.salesmanagement.exceptions.InvalidPriceException;
import com.cg.salesmanagement.dao.ISaleDAO;
import com.cg.salesmanagement.dao.SaleDAO;

public class SaleService implements ISaleService{

	ISaleDAO dao=new SaleDAO();
	Sale sale=new Sale();
	@Override

	//	Sale sale=new Sale(prodCode, productName, category, saleDate, quantity, lineTotal);
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {

		return dao.insertSalesDetails(sale);
	}



	@Override
	public boolean validateProductCode(int ProductId) {
		// TODO Auto-generated method stub
		if(!(ProductId==1001||ProductId==1002||ProductId==1003||ProductId==1004)){
			throw new  InValidProductCodeException("Sorry! <<"+sale.getProdCode()+">> is not available");}
		else 
			return true;
	}

	@Override
	public boolean validateQuantity(int qty) {
		// TODO Auto-generated method stub
		if(!(qty>0&&qty<5))
		{throw new InValidQuantityException("it is invalid quantity");
		}
		else 
			return true;
	}

	@Override
	public boolean validateProductCat(String prodCat) {
		if(!(prodCat.equalsIgnoreCase("electronics")||prodCat.equalsIgnoreCase("toys")))

		{
			throw new InValidProductCategoryException("product category is not valid");
		}
		else
			return true;
	}


	@Override
	public boolean validateProductCatName(String prodName,String prodCat) {
		if(prodCat.equalsIgnoreCase("electronics")){
			if(!(prodName.equals("TV")||prodName.equals("Smart Phone")||prodName.equals("Video Game")))

			{throw new InValidProductNameException("it is invalid product name");
			}



		}


		else if(prodCat.equalsIgnoreCase("toys")){
			if(!(prodName.equals("Soft Toy")||prodName.equals("Telescope")||prodName.equals("Baebee Doll")))

				throw new InValidProductCategoryException("it is invalid productName");		
		}
		return false;

	}

	@Override
	public boolean validateProductPrice(float price) {
		// TODO Auto-generated method stub
		if(!(price==35000)) {
			throw new InvalidPriceException("invalid price");
		}
		return true;
	}






}
