package com.capgemini.salesmanagement.service;

import java.time.LocalDate;
import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;

public interface ISaleService {
	public HashMap<Integer,Sale>insertSalesDetails( Sale sale);
	
	public boolean validateProductCode(int ProductId);
	boolean validateQuantity(int qty);
	public boolean validateProductCat(String prodCat);
	public boolean validateProductCatName(String prodName,String prodCat);
	public boolean validateProductPrice(float price);



	
}
