package com.capgemini.salesmanagement.ui;

import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exceptions.InValidProductCategoryException;
import com.capgemini.salesmanagement.exceptions.InValidProductNameException;
import com.capgemini.salesmanagement.exceptions.InvalidPriceException;
import com.capgemini.salesmanagement.service.SaleService;

public class Client {
	SaleService saleService=new SaleService();
	public void enterDetails() {
		Scanner sc= new Scanner(System.in);
	  System.out.println("Enter the product code");
      int productcode=0;
	try {
		productcode = sc.nextInt();
		  saleService.validateProductCode(productcode);
	} catch (Exception e) {
	
		e.printStackTrace();
	}
      System.out.println("enter the qunantity");
 
      int quant=0;
	try {
		quant = sc.nextInt();
		  saleService.validateQuantity(quant);
	} catch (Exception e) {
	
		e.printStackTrace();
	}
      System.out.println("product category:");
      try {
		String prodcat=sc.next();
		  saleService.validateProductCat(prodcat);
		  System.out.println("product name:");
		String prodnam=sc.next();
		  saleService.validateProductCatName(prodnam,prodcat);
		  System.out.println("Product price(Rs):");
		  int price=sc.nextInt();
		  saleService.validateProductPrice(price);
		 
		  Date date= new Date();
  LocalDate d=    LocalDate.now();
		  float lineTotal=quant*price;
		 // System.out.println("Line Total(Rs):"+quant*price);
		  
		  
		  
		  
		  //below is contructor for getting values;
		  
		  
		  
Sale sale1=new Sale(productcode, prodnam, prodcat,d , quant, lineTotal);
System.out.println(saleService.insertSalesDetails(sale1));
	} 
      catch(InValidProductCategoryException e)
      {
    	  System.out.println(e.getMessage());
      }
      catch(InValidProductNameException e)
      {
    	  System.out.println(e.getMessage());
      }
      catch(InvalidPriceException e)
      {
    	  System.out.println(e.getMessage());
      }
     

      



	}
	//System.out.println(sale);}
    public static void main(String[] args) {
    
Client c= new Client();
boolean flag=true;

while(flag)
{System.out.println("enter 1 for calculating bill and 2 for exiting from the system");
Scanner sc= new Scanner(System.in);
int ch=sc.nextInt();

switch(ch) {
case 1:
	c.enterDetails();


break;
case 2:
	System.exit(ch);
	flag=false;
default:
	System.out.println("your transaction is complete");
}}}}